import { NotFoundContainer } from "./styledComponents"

const NotFound = () => (
    <NotFoundContainer>Not Found</NotFoundContainer>
)

export default NotFound